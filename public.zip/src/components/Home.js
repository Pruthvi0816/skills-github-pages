import React, { useState, useEffect } from 'react';
import { Box, Typography, Container, Grid, Paper } from '@mui/material';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import styled from '@emotion/styled';

const SliderContainer = styled(Box)`
  position: relative;
  height: 80vh;
  overflow: hidden;
  margin-bottom: 4rem;
  background: linear-gradient(45deg, #000000, #1a1a1a);
`;

const Slide = styled(motion.div)`
  position: absolute;
  width: 100%;
  height: 100%;
  background-size: cover;
  background-position: center;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  text-align: center;
`;

const SlideContent = styled(Box)`
  background: rgba(0, 0, 0, 0.7);
  padding: 2rem;
  border-radius: 1rem;
  backdrop-filter: blur(5px);
  border: 1px solid rgba(255, 255, 255, 0.1);
`;

const FeatureCard = styled(motion(Paper))`
  padding: 2rem;
  text-align: center;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  background: linear-gradient(135deg, #ffffff, #f5f5f5);
  border: 1px solid rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
  }
`;

const slides = [
  {
    image: '/images/chaha.jpg',
    title: 'चंदू स्पेशल चाहा',
    subtitle: 'Premium Quality Tea',
    description: 'Experience the finest blend of spices and tea leaves',
  },
  {
    image: '/images/gulacha.jpeg',
    title: 'Fresh Tea',
    subtitle: 'Made with Love',
    description: 'Brewed fresh daily with premium ingredients',
  },
  {
    image: '/images/images.jpeg',
    title: 'Dairy Products',
    subtitle: 'Fresh and Pure',
    description: 'Direct from local farms to your cup',
  },
];

const features = [
  {
    icon: '☕',
    title: 'Premium Quality चाहा',
    description: 'आणि योग्य भावात',
    color: '#4a148c',
  },
  {
    icon: '🌟',
    title: 'Best Service',
    description: 'Customer satisfaction guaranteed',
    color: '#1a237e',
  },
  {
    icon: '💯',
    title: 'Quality Assurance',
    description: '100% quality check on all products',
    color: '#311b92',
  },
];

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  return (
    <Box sx={{ bgcolor: '#f5f5f5' }}>
      <SliderContainer>
        <AnimatePresence mode="wait">
          <Slide
            key={currentSlide}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            style={{
              backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(${slides[currentSlide].image})`,
            }}
          >
            <SlideContent>
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <Typography 
                  variant="h2" 
                  gutterBottom 
                  sx={{ 
                    color: '#ffffff',
                    textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
                    fontWeight: 'bold'
                  }}
                >
                  {slides[currentSlide].title}
                </Typography>
                <Typography 
                  variant="h5" 
                  sx={{ 
                    color: '#e0e0e0',
                    mb: 2
                  }}
                >
                  {slides[currentSlide].subtitle}
                </Typography>
                <Typography 
                  variant="body1" 
                  sx={{ 
                    color: '#bdbdbd',
                    maxWidth: '600px',
                    margin: '0 auto'
                  }}
                >
                  {slides[currentSlide].description}
                </Typography>
              </motion.div>
            </SlideContent>
          </Slide>
        </AnimatePresence>
      </SliderContainer>

      <Container ref={ref}>
        <Grid container spacing={4} sx={{ mb: 8 }}>
          {features.map((feature, index) => (
            <Grid item xs={12} md={4} key={index}>
              <FeatureCard
                elevation={3}
                initial={{ y: 50, opacity: 0 }}
                animate={inView ? { y: 0, opacity: 1 } : {}}
                transition={{ delay: index * 0.2 }}
              >
                <Typography 
                  variant="h1" 
                  sx={{ 
                    fontSize: '3rem',
                    color: feature.color
                  }}
                >
                  {feature.icon}
                </Typography>
                <Typography 
                  variant="h5" 
                  gutterBottom
                  sx={{ 
                    color: feature.color,
                    fontWeight: 'bold'
                  }}
                >
                  {feature.title}
                </Typography>
                <Typography 
                  color="text.secondary"
                  sx={{ 
                    fontSize: '1.1rem'
                  }}
                >
                  {feature.description}
                </Typography>
              </FeatureCard>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Home; 