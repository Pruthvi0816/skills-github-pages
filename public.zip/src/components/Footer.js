import React from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  IconButton,
  Link,
} from '@mui/material';
import {
  Facebook as FacebookIcon,
  Instagram as InstagramIcon,
  WhatsApp as WhatsAppIcon,
  Email as EmailIcon,
} from '@mui/icons-material';
import styled from '@emotion/styled';

const FooterContainer = styled(Box)`
  background-color: #1a1a1a;
  color: white;
  padding: 4rem 0 2rem;
  margin-top: 4rem;
`;

const SocialButton = styled(IconButton)`
  color: white;
  margin: 0.5rem;
  transition: transform 0.2s;
  
  &:hover {
    transform: scale(1.1);
    color: #ff6f00;
  }
`;

const Footer = () => {
  return (
    <FooterContainer>
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom>
              चंदू स्पेशल चाहा
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ color: '#999' }}>
              Premium quality tea and dairy products with exceptional service.
              Serving the community with love and dedication.
            </Typography>
          </Grid>

          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom>
              Quick Links
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              <Link href="/" color="inherit" underline="hover">
                Home
              </Link>
              <Link href="/about" color="inherit" underline="hover">
                About Us
              </Link>
              <Link href="/services" color="inherit" underline="hover">
                Services
              </Link>
              <Link href="/contact" color="inherit" underline="hover">
                Contact
              </Link>
            </Box>
          </Grid>

          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom>
              Connect With Us
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
              <SocialButton
                href="https://www.facebook.com/share/19Mnxc5wn7/"
                target="_blank"
                aria-label="Facebook"
              >
                <FacebookIcon />
              </SocialButton>
              <SocialButton
                href="https://www.instagram.com/gangane__chandrakant?igsh=bnRqZWh1cnY5c2g0"
                target="_blank"
                aria-label="Instagram"
              >
                <InstagramIcon />
              </SocialButton>
              <SocialButton
                href="https://wa.me/919284407734"
                target="_blank"
                aria-label="WhatsApp"
              >
                <WhatsAppIcon />
              </SocialButton>
              <SocialButton
                href="mailto:chandrakantgangane24@gmail.com"
                aria-label="Email"
              >
                <EmailIcon />
              </SocialButton>
            </Box>
            <Typography variant="body2" color="text.secondary" sx={{ color: '#999' }}>
              Shivaji Chauk, Gaurgaon, Maharashtra
            </Typography>
          </Grid>
        </Grid>

        <Box
          sx={{
            mt: 4,
            pt: 2,
            borderTop: '1px solid rgba(255, 255, 255, 0.1)',
            textAlign: 'center',
          }}
        >
          <Typography variant="body2" color="text.secondary" sx={{ color: '#999' }}>
            © {new Date().getFullYear()} Chandrakant Gangane. चंदू स्पेशल चाहा. All rights reserved.
          </Typography>
        </Box>
      </Container>
    </FooterContainer>
  );
};

export default Footer; 