import React from 'react';
import {
  Container,
  Grid,
  Typography,
  Card,
  CardContent,
  CardMedia,
  Button,
  Box,
} from '@mui/material';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import styled from '@emotion/styled';

const ServiceCard = styled(motion(Card))`
  height: 100%;
  display: flex;
  flex-direction: column;
  transition: transform 0.3s ease-in-out;
  
  &:hover {
    transform: translateY(-10px);
  }
`;

const services = [
  {
    title: 'चंदू स्पेशल चाहा',
    description: 'Premium quality tea made with fresh ingredients and special spices.',
    image: '/images/chaha.jpg',
    link: '/',
  },
  {
    title: 'दूध डेरी सर्व माहिती',
    description: 'Complete dairy information and various price ranges for all your dairy needs.',
    image: '/images/images.jpeg',
    link: '/deri.html',
  },
  {
    title: 'Fresh Tea',
    description: 'Daily fresh tea made with love and care.',
    image: '/images/gulacha.jpeg',
    link: '/',
  },
];

const Services = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      <Typography
        variant="h2"
        align="center"
        gutterBottom
        sx={{ mb: 6 }}
      >
        Our Services
      </Typography>

      <Grid container spacing={4} ref={ref}>
        {services.map((service, index) => (
          <Grid item xs={12} md={4} key={index}>
            <ServiceCard
              elevation={3}
              initial={{ y: 50, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ delay: index * 0.2 }}
            >
              <CardMedia
                component="img"
                height="200"
                image={service.image}
                alt={service.title}
                sx={{ objectFit: 'cover' }}
              />
              <CardContent sx={{ flexGrow: 1 }}>
                <Typography gutterBottom variant="h5" component="h2">
                  {service.title}
                </Typography>
                <Typography color="text.secondary" paragraph>
                  {service.description}
                </Typography>
                <Box sx={{ mt: 2 }}>
                  <Button
                    variant="contained"
                    color="primary"
                    href={service.link}
                    fullWidth
                  >
                    Learn More
                  </Button>
                </Box>
              </CardContent>
            </ServiceCard>
          </Grid>
        ))}
      </Grid>

      <Box
        sx={{
          mt: 8,
          p: 4,
          bgcolor: 'background.paper',
          borderRadius: 2,
          textAlign: 'center',
        }}
      >
        <Typography variant="h4" gutterBottom>
          Why Choose Us?
        </Typography>
        <Grid container spacing={3} sx={{ mt: 2 }}>
          <Grid item xs={12} md={4}>
            <Typography variant="h6" color="primary" gutterBottom>
              Quality Assurance
            </Typography>
            <Typography>
              We maintain the highest standards of quality in all our products.
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Typography variant="h6" color="primary" gutterBottom>
              Customer Service
            </Typography>
            <Typography>
              Dedicated support team available to assist you 24/7.
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Typography variant="h6" color="primary" gutterBottom>
              Fast Delivery
            </Typography>
            <Typography>
              Quick and reliable delivery service to your location.
            </Typography>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default Services; 