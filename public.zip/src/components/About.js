import React from 'react';
import {
  Container,
  Grid,
  Typography,
  Box,
  Paper,
} from '@mui/material';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import styled from '@emotion/styled';

const AboutCard = styled(motion(Paper))`
  padding: 2rem;
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const ImageContainer = styled(motion.div)`
  position: relative;
  overflow: hidden;
  border-radius: 1rem;
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, rgba(0,0,0,0.3), transparent);
  }
`;

const About = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      <Typography
        variant="h2"
        align="center"
        gutterBottom
        sx={{ mb: 6 }}
      >
        About Us
      </Typography>

      <Grid container spacing={4} ref={ref}>
        <Grid item xs={12} md={6}>
          <AboutCard
            elevation={3}
            initial={{ x: -50, opacity: 0 }}
            animate={inView ? { x: 0, opacity: 1 } : {}}
            transition={{ duration: 0.5 }}
          >
            <Typography variant="h4" gutterBottom color="primary">
              Our Story
            </Typography>
            <Typography paragraph>
              चंदू स्पेशल चाहा is a family-owned business that has been serving
              the community with premium quality tea and dairy products for
              generations. Our commitment to quality and customer satisfaction
              has made us a trusted name in the industry.
            </Typography>
            <Typography paragraph>
              We take pride in our traditional methods of preparation while
              incorporating modern techniques to ensure the highest standards
              of quality and hygiene.
            </Typography>
            <Typography paragraph>
              Our mission is to provide our customers with the finest quality
              products at competitive prices, backed by exceptional service.
            </Typography>
          </AboutCard>
        </Grid>

        <Grid item xs={12} md={6}>
          <ImageContainer
            initial={{ x: 50, opacity: 0 }}
            animate={inView ? { x: 0, opacity: 1 } : {}}
            transition={{ duration: 0.5 }}
          >
            <img
              src="/images/chaha.jpg"
              alt="About Us"
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
              }}
            />
          </ImageContainer>
        </Grid>
      </Grid>

      <Box sx={{ mt: 8 }}>
        <Grid container spacing={4}>
          <Grid item xs={12} md={4}>
            <AboutCard
              elevation={3}
              initial={{ y: 50, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ delay: 0.2 }}
            >
              <Typography variant="h5" gutterBottom color="primary">
                Our Values
              </Typography>
              <Typography>
                • Quality First
                <br />
                • Customer Satisfaction
                <br />
                • Traditional Methods
                <br />
                • Innovation
                <br />
                • Community Service
              </Typography>
            </AboutCard>
          </Grid>

          <Grid item xs={12} md={4}>
            <AboutCard
              elevation={3}
              initial={{ y: 50, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ delay: 0.4 }}
            >
              <Typography variant="h5" gutterBottom color="primary">
                Our Promise
              </Typography>
              <Typography>
                We promise to deliver the highest quality products with
                exceptional service. Our commitment to excellence and
                customer satisfaction drives everything we do.
              </Typography>
            </AboutCard>
          </Grid>

          <Grid item xs={12} md={4}>
            <AboutCard
              elevation={3}
              initial={{ y: 50, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ delay: 0.6 }}
            >
              <Typography variant="h5" gutterBottom color="primary">
                Our Vision
              </Typography>
              <Typography>
                To be the leading provider of premium quality tea and dairy
                products, known for our commitment to quality, service, and
                customer satisfaction.
              </Typography>
            </AboutCard>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default About; 